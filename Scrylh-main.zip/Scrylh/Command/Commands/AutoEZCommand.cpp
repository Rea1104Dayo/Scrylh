#include "AutoEZCommand.h"

#include "../../Module/ModuleManager.h"
#include "pch.h"

AutoEZCommand::AutoEZCommand() : IMCCommand("AutoEZ", "Edit AutoEZCommand text", "<died/kill> <string>") {
}

bool AutoEZCommand::execute(std::vector<std::string>* args) {
	assertTrue(g_Data.getLocalPlayer() != nullptr);
	if (args->at(1) == "kill") {
		std::ostringstream os;
		for (int i = 2; i < args->size(); i++) {
			if (i > 1)
				os << " ";
			os << args->at(i);
		}
		std::string text = os.str().substr(1);
		moduleMgr->getModule<AutoEZ>()->getCustomKillMessage() = text;
		clientMessageF("[Scrylh] %sKill message set to %s%s%s!", GREEN, GRAY, text.c_str(), GREEN);
	}
	if (args->at(1) == "died") {
		std::ostringstream os;
		for (int i = 2; i < args->size(); i++) {
			if (i > 1)
				os << " ";
			os << args->at(i);
		}
		std::string text = os.str().substr(1);
		moduleMgr->getModule<AutoEZ>()->getCustomDiedMessage() = text;
		clientMessageF("[Scrylh] %sDied message set to %s%s%s!", GREEN, GRAY, text.c_str(), GREEN);
	}
	return true;
}