#include "ClientNameCommand.h"

#include "../../Module/ModuleManager.h"
#include "pch.h"

ClientNameCommand::ClientNameCommand() : IMCCommand("clientname", "", "clientname <set/reset> <string>") {
}

bool ClientNameCommand::execute(std::vector<std::string>* args) {
	assertTrue(g_Data.getLocalPlayer() != nullptr);
	if (args->at(1) == "set") {
		std::ostringstream os;
		for (int i = 2; i < args->size(); i++) {
			if (i > 1)
				os << " ";
			os << args->at(i);
		}
		moduleMgr->getModule<ChatSuffix>()->getCustomMessage2() = os.str().substr(1);
		moduleMgr->getModule<Watermark>()->getCustomWatermarkMessage() = os.str().substr(1);
		clientMessageF("[Scrylh] %sClientName set to %s%s%s!", GREEN, GRAY, os.str().substr(1), GREEN);
	}
	if (args->at(1) == "reset") {
		moduleMgr->getModule<ChatSuffix>()->getCustomMessage2() = "Scrylh";
		moduleMgr->getModule<Watermark>()->getCustomWatermarkMessage() = "Scrylh";
		clientMessageF("[Scrylh] %sClientName is Reseted!");
	}
	return true;
}