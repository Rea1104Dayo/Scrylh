#pragma once
#include "ICommand.h"
class DamageCommand : public IMCCommand {
public:
	DamageCommand();
};
