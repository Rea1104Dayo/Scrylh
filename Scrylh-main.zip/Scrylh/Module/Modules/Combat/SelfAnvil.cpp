#include "SelfAnvil.h"
#include "../../ModuleManager.h"

SelfAnvil::SelfAnvil() : IModule(0x0, Category::COMBAT, "SelfAnvil)") {

}

SelfAnvil::~SelfAnvil() {
}

const char* SelfAnvil::getModuleName() {
	return "SelfAnvil";
}
bool Place(vec3_t placement) {
	placement = placement.floor();
	C_Block* block = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(placement));
	C_BlockLegacy* blockLegacy = block->blockLegacy;
	if (blockLegacy->material->isReplaceable) {
		vec3_ti blocks(placement);
		int i = 0;

		static const std::vector<vec3_ti> checklist = {vec3_ti(0, -1, 0), vec3_ti(0, 1, 0), vec3_ti(0, 0, -1), vec3_ti(0, 0, 1), vec3_ti(-1, 0, 0), vec3_ti(1, 0, 0) };

		bool foundCandidate = false;

		for (const auto& current : checklist) {
			vec3_ti calculation = blocks.sub(current);
			bool Y = (g_Data.getLocalPlayer()->region->getBlock(calculation)->blockLegacy)->material->isReplaceable;
			if (!(g_Data.getLocalPlayer()->region->getBlock(calculation)->blockLegacy)->material->isReplaceable) {
				// Found a solid block to click
				foundCandidate = true;
				blocks = calculation;
				break;
			}
			i++;
		}

		if (foundCandidate) {
			// Check if there is a button below the player's feet


			// Call buildBlock directly to place the block silently
			g_Data.getCGameMode()->buildBlock(&blocks, i);
			return true;
		}
	}

	return false;
}
void PlaceBlock(const vec3_t& blockPos) {
	vec3_t BlockPos1 = blockPos.add(vec3_t(0, 2, 0));
	vec3_t BlockPos2 = blockPos.add(vec3_t(0, 1, 0));
	Place(BlockPos1);
	Place(BlockPos2);
}

void SelfAnvil::onTick(C_GameMode* gm) {
C_GameSettingsInput* input = g_Data.getClientInstance()->getGameSettingsInput();
if (g_Data.getLocalPlayer() == nullptr) {
	return;
}
if (!g_Data.canUseMoveKeys()) {
	return;
}
vec3_t playerPos = g_Data.getLocalPlayer()->getPos()->floor();
vec3_t Obsidian1 = playerPos.add(vec3_t(1, -3, 0));
vec3_t Obsidian2 = playerPos.add(vec3_t(1, -2, 0));
vec3_t Obsidian3 = playerPos.add(vec3_t(1, -1, 0));
vec3_t Anvil     = playerPos.add(vec3_t(0, 0, 0));

if (placed == 0) {
	// Silent Code
	int slotab = 0;
	C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
	C_Inventory* inv = supplies->inventory;
	slotab = supplies->selectedHotbarSlot;
	for (int n = 0; n < 9; n++) {
		C_ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			if (stack->getItem()->itemId == 49) {
				supplies->selectedHotbarSlot = n;
				break;
			}
		}
	}
	PlaceBlock(Obsidian1);
	PlaceBlock(Obsidian2);
	PlaceBlock(Obsidian3);
	supplies->selectedHotbarSlot = slotab;
	slotab = 0;
	slotab = supplies->selectedHotbarSlot;
	for (int n = 0; n < 9; n++) {
		C_ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			if (stack->getItem()->itemId == 145) {
				supplies->selectedHotbarSlot = n;
				break;
			}
		}
	}
	PlaceBlock(Anvil);
	supplies->selectedHotbarSlot = slotab;
	placed = 1;
	}
}
void SelfAnvil::onDisable() {
	placed = 0;
}