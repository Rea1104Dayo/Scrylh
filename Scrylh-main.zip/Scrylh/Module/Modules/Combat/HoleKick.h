#pragma once
#include "../../ModuleManager.h"
#include "../Module.h"

class HoleKick : public IModule {
private:
	bool tryHoleKick(vec3_t HoleKick);
public:
	HoleKick();
	virtual const char* getModuleName();
	virtual void onTick(C_GameMode* gm);
};
