#pragma once
#include "../Module.h"
#include "../../../../Utils/TargetUtil.h"
#include "../../ModuleManager.h"
class TrapPlayer : public IModule {
private:

	bool tryTrapPlayer(vec3_t TrapPlayer);

public:
	TrapPlayer();
	~TrapPlayer();
	SettingEnum mode = this;
	int range = 7;
	bool onClick = false;
	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onTick(C_GameMode* gm) override;
};
