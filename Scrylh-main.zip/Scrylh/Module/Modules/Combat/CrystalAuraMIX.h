#pragma once
#include "../../ModuleManager.h"
#include "../Module.h"

class CrystalAuraMIX : public IModule {
private:
	int delay = 0;
	bool autoplace = true;
	bool crystalCheck = true;
	bool yLock = false;
	bool isClick = false;
	bool silent = false;
	int slotCA = 0;
	bool renderCA = true;
	bool oldrdca = false;

public:
	CrystalAuraMIX();
	~CrystalAuraMIX();

	// Inherited via IModule
	virtual const char* getModuleName();
	virtual void onTick(C_GameMode* gm);
	virtual void onEnable();
	virtual void onDisable();
	int range = 7;
	//bool BadMan = true;
	virtual void onPreRender(C_MinecraftUIRenderContext* renderCtx);
	vec3_t espPosUpper1M;
	vec3_t espPosLower1M;
};
#pragma once
