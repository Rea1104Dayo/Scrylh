#pragma once
#include "../Module.h"
class TrapAnvil : public IModule {
private:
	int obsiheight = 3;
	int anvilheight = 3;
	bool Bypass = true;
	bool tryTrapAnvil(vec3_t TrapAnvil);

public:
	TrapAnvil();
	~TrapAnvil();

	int range = 10;
	bool multiplace = false;
	bool onClick = false;
	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onTick(C_GameMode* gm) override;
};
