#include "HoleKick.h"

HoleKick::HoleKick() : IModule(0, Category::COMBAT, "Piston->Hole Kick") {
}

const char* HoleKick::getModuleName() {
	return ("HoleKick");
}

static std::vector<C_Entity*> targetList21;

void findEntity21(C_Entity* currentEntity21, bool isRegularEntity) {
	static auto HoleKickMod = moduleMgr->getModule<HoleKick>();

	if (currentEntity21 == nullptr)
		return;

	if (currentEntity21 == g_Data.getLocalPlayer())  // Skip Local player
		return;

	if (!g_Data.getLocalPlayer()->canAttack(currentEntity21, false))
		return;

	if (!g_Data.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity21->isAlive())
		return;


	if (!TargetUtil::isValidTarget(currentEntity21))
		return;

	float dist = (*currentEntity21->getPos()).dist(*g_Data.getLocalPlayer()->getPos());
	if (dist < 8) {
		targetList21.push_back(currentEntity21);

		float dist = (*currentEntity21->getPos()).dist(*g_Data.getLocalPlayer()->getPos());

		if (dist < 8) {
			targetList21.push_back(currentEntity21);
		}
	}
}

bool HoleKick::tryHoleKick(vec3_t HoleKick) {
	HoleKick = HoleKick.floor();

	C_Block* block = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(HoleKick));
	C_BlockLegacy* blockLegacy = (block->blockLegacy);
	if (blockLegacy->material->isReplaceable) {
		vec3_ti blok(HoleKick);

		// Find neighbour
		static std::vector<vec3_ti*> checklist;
		if (checklist.empty()) {
			checklist.push_back(new vec3_ti(0, -1, 0));
			checklist.push_back(new vec3_ti(0, 1, 0));

			checklist.push_back(new vec3_ti(0, 0, -1));
			checklist.push_back(new vec3_ti(0, 0, 1));

			checklist.push_back(new vec3_ti(-1, 0, 0));
			checklist.push_back(new vec3_ti(1, 0, 0));
		}

		bool foundCandidate = false;
		int i = 0;
		for (auto current : checklist) {
			vec3_ti calc = blok.sub(*current);
			bool Y = ((g_Data.getLocalPlayer()->region->getBlock(calc)->blockLegacy))->material->isReplaceable;
			if (!((g_Data.getLocalPlayer()->region->getBlock(calc)->blockLegacy))->material->isReplaceable) {
				// Found a solid block to click
				foundCandidate = true;
				blok = calc;
				break;
			}
			i++;
		}
		if (foundCandidate) {
			g_Data.getCGameMode()->buildBlock(&blok, i);

			return true;
		}
	}
	return false;
}
void HoleKick::onTick(C_GameMode* gm) {
	C_GameSettingsInput* input = g_Data.getClientInstance()->getGameSettingsInput();
	if (g_Data.getLocalPlayer() == nullptr) {
		return;
	}
	if (!g_Data.canUseMoveKeys()) {
		return;
	}
	auto selectedItem = g_Data.getLocalPlayer()->getSelectedItem();
	if ((selectedItem == nullptr || selectedItem->count == 0 || selectedItem->item == nullptr || !selectedItem->getItem()->isBlock())) {
		return;
	}
	targetList21.clear();
	g_Data.forEachEntity(findEntity21);
	if (!targetList21.empty()) {
		vec3_t Piston = targetList21[0]->eyePos0;
		vec3_t RedstoneBlock = targetList21[0]->eyePos0;
		Piston.x -= targetList21[0]->height - 1;
		Piston.z -= targetList21[0]->height - 2;
		Piston.y += targetList21[0]->height - 2;
		RedstoneBlock.x += targetList21[0]->height - 3;
		RedstoneBlock.z -= targetList21[0]->height - 1;
		RedstoneBlock.y += targetList21[0]->height - 2;
		int slotab = 0;
		C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
		C_Inventory* inv = supplies->inventory;
		slotab = supplies->selectedHotbarSlot;
		for (int n = 0; n < 9; n++) {
			C_ItemStack* stack = inv->getItemStack(n);
			if (stack->item != nullptr) {
				if (stack->getItem()->itemId == 29) {
					supplies->selectedHotbarSlot = n;
					break;
				}
				if (stack->getItem()->itemId == 33) {
					supplies->selectedHotbarSlot = n;
					break;
				}

			}
		}
		if (!tryHoleKick(Piston)) {
			Piston.x -= 0;
			Piston.z -= 0;
		}
		supplies->selectedHotbarSlot = slotab;
		slotab = 0;
		for (int n = 0; n < 9; n++) {
			C_ItemStack* stack = inv->getItemStack(n);
			if (stack->item != nullptr) {
				if (stack->getItem()->itemId == 152) {
					supplies->selectedHotbarSlot = n;
					break;
				}
			}
		}
		if (!tryHoleKick(RedstoneBlock)) {
			RedstoneBlock.x -= 0;
			RedstoneBlock.z -= 0;
		}
		supplies->selectedHotbarSlot = slotab;
	}
}