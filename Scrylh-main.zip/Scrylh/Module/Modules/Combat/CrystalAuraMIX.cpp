#include "CrystalAuraMIX.h"
#include <cmath>
#include <vector>
#include <algorithm>

CrystalAuraMIX::CrystalAuraMIX() : IModule(0x0, Category::COMBAT, "CrystalAura by Tony UWU") {
	registerIntSetting("range", &range, range, 1, 10);
	registerBoolSetting("autoplace", &autoplace, autoplace);

	registerIntSetting("delay", &delay, delay, 0, 20);
	registerBoolSetting("onClick", &isClick, isClick);

}
int crystalDelay1M = 0;
int crystalDelay2M = 0;
int crystalDelay3M = 0;

CrystalAuraMIX::~CrystalAuraMIX() {
}

const char* CrystalAuraMIX::getModuleName() {
	return ("CrystalAuraMIX");
}
static std::vector<C_Entity*> targetList1M;

struct CompareTargetEnArray {
	bool operator()(C_Entity* lhs, C_Entity* rhs) {
		C_LocalPlayer* localPlayer = g_Data.getLocalPlayer();
		return (*lhs->getPos()).dist(*localPlayer->getPos()) < (*rhs->getPos()).dist(*localPlayer->getPos());
	}
};

void findEntity1M(C_Entity* currentEntity, bool isRegularEntity) {
	static auto CrystalAuraMIXMod = moduleMgr->getModule<CrystalAuraMIX>();

	if (currentEntity == nullptr)
		return;

	if (currentEntity->getNameTag()->getTextLength() <= 1 && currentEntity->getEntityTypeId() == 71)
		return;

	if (currentEntity == g_Data.getLocalPlayer())
		return;

	if (!g_Data.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity->isAlive())
		return;

	if (currentEntity->getNameTag()->getTextLength() <= 1 && currentEntity->getEntityTypeId() == 319)
		return;
	if (currentEntity->width <= 0.01f || currentEntity->height <= 0.01f)
		return;
	if (currentEntity->getEntityTypeId() == 64)
		return;
	if (currentEntity->getEntityTypeId() == 69)
		return;
	if (currentEntity->getEntityTypeId() == 80)
		return;

	if (!TargetUtil::isValidTarget(currentEntity))
		return;

	float dist = (*currentEntity->getPos()).dist(*g_Data.getLocalPlayer()->getPos());

	if (dist < CrystalAuraMIXMod->range) {
		targetList1M.push_back(currentEntity);
		sort(targetList1M.begin(), targetList1M.end(), CompareTargetEnArray());
	}
}

bool checkTargCollision1M(vec3_t* block, C_Entity* ent) {
	vec3_t entPos = ent->getPos()->floor();
	entPos.y -= 1;
	std::vector<vec3_t*> corners;
	corners.clear();

	if (block->x >= entPos.x && block->x <= entPos.x + 1 &&
		block->y >= entPos.y && block->y <= entPos.y + 1 &&
		block->z >= entPos.z && block->z <= entPos.z + 1) {
		return true;
	}
	corners.push_back(new vec3_t(ent->aabb.lower.x, ent->aabb.lower.y, ent->aabb.lower.z));
	corners.push_back(new vec3_t(ent->aabb.lower.x, ent->aabb.lower.y, ent->aabb.upper.z));
	corners.push_back(new vec3_t(ent->aabb.upper.x, ent->aabb.lower.y, ent->aabb.upper.z));
	corners.push_back(new vec3_t(ent->aabb.upper.x, ent->aabb.lower.y, ent->aabb.lower.z));

	std::vector<std::pair<vec3_t*, float>> cornerScores;
	for (auto corner : corners) {
		float distance = corner->distanceTo(*block);
		cornerScores.push_back(std::pair<vec3_t*, float>(corner, distance));
	}

	std::sort(cornerScores.begin(), cornerScores.end(),
		[](const auto& a, const auto& b) { return a.second < b.second; });

	for (auto scorePair : cornerScores) {
		auto corner = scorePair.first;

		if ((floor(corner->x) == floor(block->x)) && (floor(corner->y) == floor(block->y)) && (floor(corner->z) == floor(block->z))) {
			return true;
		}
	}

	return false;
}

bool checkSurrounded1M(C_Entity* ent) {
	vec3_t entPos = ent->getPos()->floor();
	entPos.y -= 1;
	std::vector<vec3_ti*> blockChecks;
	blockChecks.clear();

	blockChecks.push_back(new vec3_ti(entPos.x, entPos.y, entPos.z + 1));
	blockChecks.push_back(new vec3_ti(entPos.x, entPos.y, entPos.z - 1));
	blockChecks.push_back(new vec3_ti(entPos.x + 1, entPos.y, entPos.z));
	blockChecks.push_back(new vec3_ti(entPos.x - 1, entPos.y, entPos.z));

	bool isPlusXBlock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 1, entPos.y, entPos.z))->toLegacy()->blockId != 0;
	bool isMinusXBlock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x - 1, entPos.y, entPos.z))->toLegacy()->blockId != 0;
	bool isPlusZBlock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z + 1))->toLegacy()->blockId != 0;
	bool isMinusZBlock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z - 1))->toLegacy()->blockId != 0;

	bool isBlockedPlusX = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 2, entPos.y, entPos.z))->toLegacy()->blockId != 0;
	bool isBlockedMinusX = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x - 2, entPos.y, entPos.z))->toLegacy()->blockId != 0;
	bool isBlockedPlusZ = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z + 2))->toLegacy()->blockId != 0;
	bool isBlockedMinusZ = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z - 2))->toLegacy()->blockId != 0;

	if ((isPlusXBlock && isBlockedPlusX) || (isMinusXBlock && isBlockedMinusX) ||
		(isPlusZBlock && isBlockedPlusZ) || (isMinusZBlock && isBlockedMinusZ)) {
		return false;
	}
	else {

		std::vector<std::pair<vec3_ti*, float>> blockCheckScores;
		for (auto blocks : blockChecks) {
			blockCheckScores.push_back(std::pair<vec3_ti*, float>(blocks, entPos.distanceTo(vec3_t(blocks->x, blocks->y, blocks->z))));
		}

		std::sort(blockCheckScores.begin(), blockCheckScores.end(),
			[](const auto& a, const auto& b) { return a.second < b.second; });

		for (auto scorePair : blockCheckScores) {
			auto blocks = scorePair.first;

			if (!checkTargCollision1M(&blocks->toVector3(), ent)) {
				return false;
			}
		}

		return true;
	}
}
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <memory>

const float BASE_DAMAGE = 5.0f;
const float DISTANCE_MULTIPLIER = 0.1f;
const float CRITICAL_CHANCE = 0.1f;

bool hasEnoughAirBlocks(C_Entity* ent, vec3_t* pos) {
	int airBlockCount = 0;

	for (int yOffset = 0; yOffset < 2; yOffset++) {
		vec3_t blockPos(pos->x, pos->y + yOffset, pos->z);
		if (g_Data.getLocalPlayer()->region->getBlock(vec3_ti(static_cast<int>(blockPos.x), static_cast<int>(blockPos.y), static_cast<int>(blockPos.z)))->toLegacy()->blockId == 0) {
			airBlockCount++;
		}
	}

	return airBlockCount >= 2;
}

bool canCrystalDamageTarget(C_Entity* target, vec3_t* crystalPos) {
	vec3_t targetPos = *target->getPos();
	vec3_t crystalEyePos = *crystalPos;
	crystalEyePos.y += 1.5;

	vec3_t crystalToTarget = targetPos.sub(crystalEyePos);
	double xDist = targetPos.x - crystalEyePos.x;
	double yDist = targetPos.y - crystalEyePos.y;
	double zDist = targetPos.z - crystalEyePos.z;
	double distanceToTarget = std::sqrt(xDist * xDist + yDist * yDist + zDist * zDist);

	vec3_t rayDirection = crystalToTarget.normalize();

	vec3_t currentPos = crystalEyePos;
	for (double distance = 0; distance < distanceToTarget; distance += 0.5) {
		currentPos = currentPos.add(rayDirection.mul(0.5));

		int blockId = g_Data.getLocalPlayer()->region->getBlock(currentPos.floor())->toLegacy()->blockId;
		if (blockId != 0) {
			return false;
		}
	}

	return true;
}

float vectorLength(const vec3_t& vec) {
	return std::sqrt(vec.x * vec.x + vec.y * vec.y + vec.z * vec.z);
}

float calculateDamage(vec3_t* crystalPos, C_Entity* target) {
	float distance = crystalPos->dist(*target->getPos());
	float baseDamage = BASE_DAMAGE + static_cast<float>(rand() % 6);

	float LOSMultiplier = canCrystalDamageTarget(target, crystalPos) ? 1.0f : 0.0f;

	float distanceDamage = std::max(0.0f, (1.0f - DISTANCE_MULTIPLIER * distance) * baseDamage * LOSMultiplier);
	float criticalDamage = distanceDamage;

	if (static_cast<float>(rand()) / RAND_MAX < CRITICAL_CHANCE) {
		criticalDamage *= 2.0f;
	}

	return criticalDamage;
}

struct BlockWithScore {
	vec3_t* position;
	float score;

	BlockWithScore(vec3_t* pos, float s) : position(pos), score(s) {}
};

bool compareBlockScores(const BlockWithScore& a, const BlockWithScore& b) {
	return a.score > b.score;
}

std::vector<vec3_t*> getGucciPlacement1M(C_Entity* ent) {
	vec3_t entPos = ent->getPos()->floor();
	entPos.y -= 1;
	std::vector<vec3_t*> finalBlocks;
	finalBlocks.clear();

	std::vector<BlockWithScore> blockScores;

	for (int x = -2; x <= 2; x++) {
		for (int z = -2; z <= 2; z++) {
			if (x != 0 || z != 0) {
				vec3_ti block(entPos.x + x, entPos.y, entPos.z + z);
				bool isAir = g_Data.getLocalPlayer()->region->getBlock(block)->toLegacy()->blockId == 0;
				bool isAnvil = g_Data.getLocalPlayer()->region->getBlock(block)->toLegacy()->blockId == 145;

				if (isAir && !checkTargCollision1M(&block.toVector3(), ent) && hasEnoughAirBlocks(ent, new vec3_t(block.x, block.y, block.z))) {

					if (canCrystalDamageTarget(ent, &block.toVector3())) {
						float damage = calculateDamage(&block.toVector3(), ent);
						blockScores.push_back(BlockWithScore(new vec3_t(block.x, block.y, block.z), damage));
					}
				}
				else if (isAnvil) {

					vec3_ti adjacentBlock;

					adjacentBlock = vec3_ti(block.x + 1, block.y, block.z);
					bool isAdjacentAir = g_Data.getLocalPlayer()->region->getBlock(adjacentBlock)->toLegacy()->blockId == 0;
					bool isAdjacentAnvil = g_Data.getLocalPlayer()->region->getBlock(adjacentBlock)->toLegacy()->blockId == 145;

					if (isAdjacentAir && isAdjacentAnvil && hasEnoughAirBlocks(ent, new vec3_t(adjacentBlock.x, adjacentBlock.y, adjacentBlock.z))) {

						if (canCrystalDamageTarget(ent, &adjacentBlock.toVector3())) {
							float damage = calculateDamage(&adjacentBlock.toVector3(), ent);
							blockScores.push_back(BlockWithScore(new vec3_t(adjacentBlock.x, adjacentBlock.y, adjacentBlock.z), damage));
						}
					}

				}
			}
		}
	}

	bool isPlusXblock = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 1, entPos.y, entPos.z))->toLegacy()->blockId == 0;
	bool isPlusXblock1 = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 1, entPos.y + 1, entPos.z))->toLegacy()->blockId != 0;

	bool isairblockX = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 2, entPos.y, entPos.z))->toLegacy()->blockId == 0;
	bool isairblockX1 = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 2, entPos.y + 2, entPos.z))->toLegacy()->blockId == 0;

	bool isairblockminusX = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x - 2, entPos.y, entPos.z))->toLegacy()->blockId == 0;
	bool isairblockminnusX1 = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x - 2, entPos.y + 2, entPos.z))->toLegacy()->blockId == 0;

	bool isairblockZ = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z + 2))->toLegacy()->blockId == 0;
	bool isairblockZ1 = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y + 2, entPos.z + 2))->toLegacy()->blockId == 0;

	bool isairblockminusZ = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z - 2))->toLegacy()->blockId == 0;
	bool isairblockminusZ1 = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y + 2, entPos.z - 2))->toLegacy()->blockId == 0;

	bool isPlusXAnvil = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x + 1, entPos.y, entPos.z))->toLegacy()->blockId == 145;
	bool isMinusXAnvil = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x - 1, entPos.y, entPos.z))->toLegacy()->blockId == 145;
	bool isPlusZAnvil = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z + 1))->toLegacy()->blockId == 145;
	bool isMinusZAnvil = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(entPos.x, entPos.y, entPos.z - 1))->toLegacy()->blockId == 145;

	if (isPlusXAnvil) {
		if (isairblockX && isairblockX1) {
			finalBlocks.push_back(new vec3_t(entPos.x + 2, entPos.y, entPos.z));
		}
	}
	if (isMinusXAnvil) {
		if (isairblockminusX && isairblockminnusX1) {
			finalBlocks.push_back(new vec3_t(entPos.x - 2, entPos.y, entPos.z));
		}

	}
	if (isPlusZAnvil) {
		if (isairblockZ && isairblockZ1) {
			finalBlocks.push_back(new vec3_t(entPos.x, entPos.y, entPos.z + 2));
		}

	}
	if (isMinusZAnvil) {
		if (isairblockminusZ && isairblockminusZ1) {
			finalBlocks.push_back(new vec3_t(entPos.x, entPos.y, entPos.z - 2));
		}

	}

	if (isPlusXblock && isPlusXblock1) {
		if (isairblockX && isairblockX1) {
			finalBlocks.push_back(new vec3_t(entPos.x + 2, entPos.y, entPos.z));
		}
	}

	std::sort(blockScores.begin(), blockScores.end(), compareBlockScores);

	int maxPlacementCount = 5;
	for (size_t i = 0; i < blockScores.size() && i < maxPlacementCount; i++) {
		finalBlocks.push_back(blockScores[i].position);
	}

	return finalBlocks;
}

bool hasPlaced1M = false;
void CrystalAuraMIX::onEnable() {
	crystalDelay1M = 0;
	hasPlaced1M = false;
}
vec3_t espPosLower1M;
vec3_t espPosUpper1M;
vec3_t crystalPos1M;
std::vector<vec3_t*> placeArr1M;

void findCr1M() {
	C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
	C_Inventory* inv = supplies->inventory;
	for (int n = 0; n < 9; n++) {
		C_ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			if (stack->getItem()->itemId == 637) {
				supplies->selectedHotbarSlot = n;

				return;
			}
		}
	}

}
void CrystalAuraMIX::onTick(C_GameMode* gm) {
	{
		if (g_Data.getLocalPlayer() == nullptr) return;
		if (isClick && !g_Data.isRightClickDown()) return;

		targetList1M.clear();

		g_Data.forEachEntity(findEntity1M);

		if (autoplace)
			if ((crystalDelay1M >= this->delay) && !(targetList1M.empty())) {
				crystalDelay1M = 0;
				if (!checkSurrounded1M(targetList1M[0])) {
					auto supplies = g_Data.getLocalPlayer()->getSupplies();
					auto inv = supplies->inventory;
					slotCA = supplies->selectedHotbarSlot;
					C_ItemStack* item = supplies->inventory->getItemStack(0);
					findCr1M();
					std::vector<vec3_t*> gucciPositions = getGucciPlacement1M(targetList1M[0]);

					if (!gucciPositions.empty()) {

						if (g_Data.getLocalPlayer()->getSelectedItemId() == 637) {
							placeArr1M.clear();
							for (auto place : gucciPositions) {

								if (targetList1M.empty()) return;
								gm->buildBlock(&vec3_ti(place->x, place->y - 1, place->z), 1);

								placeArr1M.push_back(new vec3_t(place->x, place->y - 1, place->z));
								hasPlaced1M = true;
							}
							g_Data.forEachEntity([](C_Entity* ent, bool b) {
								int id = ent->getEntityTypeId();

								if (id == 71 && g_Data.getLocalPlayer()->getPos()->dist(*ent->getPos()) <= 6) {

									g_Data.getCGameMode()->attack(ent);

								}

								});
						}

					} supplies->selectedHotbarSlot = slotCA;

					gucciPositions.clear();
				}
			}
			else if (!targetList1M.empty()) {
				crystalDelay1M++;
			}

	}
}

void CrystalAuraMIX::onDisable() {
	crystalDelay1M = 0;
	hasPlaced1M = false;
}


void CrystalAuraMIX::onPreRender(C_MinecraftUIRenderContext* renderCtx) {
	if (renderCA) {
		auto interfacrColor = ColorUtil::interfaceColor(1);
		C_LocalPlayer* localPlayer = g_Data.getLocalPlayer();
		if (localPlayer != nullptr && GameData::canUseMoveKeys()) {
			if (!targetList1M.empty()) {
				if (!placeArr1M.empty()) {
					for (auto postt : placeArr1M) {

						DrawUtils::setColor(interfacrColor.r, interfacrColor.g, interfacrColor.b, 1.f);

						DrawUtils::drawBox(postt->floor().add(0.f, 0.999f, 0.f), vec3_t(floor(postt->x) + 1.f, floor(postt->y) + 1.f, floor(postt->z) + 1.f), 0.5f, true);

					} placeArr1M.clear();
				}
			}



		}
	}

}