#include "TrapAnvil.h"
#include "../../ModuleManager.h"

TrapAnvil::TrapAnvil() : IModule(0x0, Category::COMBAT, "TrapAnvil By Tony!") {

	this->registerIntSetting("range", &this->range, this->range, 3, 12);
	this->registerIntSetting("Obsidian Height", &this->obsiheight, this->obsiheight, 3, 8);
	this->registerIntSetting("Anvil Height", &this->anvilheight, this->anvilheight, 3, 8);
	registerBoolSetting("Multi Place", &this->multiplace, this->multiplace);
	registerBoolSetting("onClick", &this->onClick, this->onClick);
	registerBoolSetting("2b2e", &this->Bypass, this->Bypass);

}

TrapAnvil::~TrapAnvil() {
}

const char* TrapAnvil::getModuleName() {
	return "TrapAnvil+";
}

static std::vector<C_Entity*> targetList18;

void findEntity18(C_Entity* currentEntity18, bool isRegularEntity) {
	static auto TrapAnvilMod = moduleMgr->getModule<TrapAnvil>();

	if (currentEntity18 == nullptr)
		return;

	if (currentEntity18 == g_Data.getLocalPlayer())  // Skip Local player
		return;

	if (!g_Data.getLocalPlayer()->canAttack(currentEntity18, false))
		return;
	if (!g_Data.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity18->isAlive())
		return;


	if (!TargetUtil::isValidTarget(currentEntity18))
		return;

	float dist = (*currentEntity18->getPos()).dist(*g_Data.getLocalPlayer()->getPos());
	if (dist < TrapAnvilMod->range) {
		targetList18.push_back(currentEntity18);

		float dist = (*currentEntity18->getPos()).dist(*g_Data.getLocalPlayer()->getPos());

		if (dist < TrapAnvilMod->range) {
			targetList18.push_back(currentEntity18);
		}
	}
}

bool TrapAnvil::tryTrapAnvil(vec3_t TrapAnvil) {
	TrapAnvil = TrapAnvil.floor();

	C_Block* block = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(TrapAnvil));
	C_BlockLegacy* blockLegacy = (block->blockLegacy);
	if (blockLegacy->material->isReplaceable) {
		vec3_ti blok(TrapAnvil);

		// Find neighbour
		static std::vector<vec3_ti*> checklist;
		if (checklist.empty()) {
			checklist.push_back(new vec3_ti(0, -1, 0));
			checklist.push_back(new vec3_ti(0, 1, 0));

			checklist.push_back(new vec3_ti(0, 0, -1));
			checklist.push_back(new vec3_ti(0, 0, 1));

			checklist.push_back(new vec3_ti(-1, 0, 0));
			checklist.push_back(new vec3_ti(1, 0, 0));
		}

		bool foundCandidate = false;
		int i = 0;
		for (auto current : checklist) {
			vec3_ti calc = blok.sub(*current);
			bool Y = ((g_Data.getLocalPlayer()->region->getBlock(calc)->blockLegacy))->material->isReplaceable;
			if (!((g_Data.getLocalPlayer()->region->getBlock(calc)->blockLegacy))->material->isReplaceable) {
				// Found a solid block to click
				foundCandidate = true;
				blok = calc;
				break;
			}
			i++;
		}
		if (foundCandidate) {
			g_Data.getCGameMode()->buildBlock(&blok, i);

			return true;
		}
	}
	return false;
}

void TrapAnvil::onTick(C_GameMode* gm) {
	C_GameSettingsInput* input = g_Data.getClientInstance()->getGameSettingsInput();
	if (g_Data.getLocalPlayer() == nullptr)
		return;
	if (!g_Data.canUseMoveKeys())
		return;
	if (obsiheight < anvilheight) {
		obsiheight = anvilheight;
	}
	if (Bypass) {
		if (anvilheight > 7) {
			anvilheight = 6;
		}
		if (obsiheight > 7) {
			obsiheight = 6;
		}
	}
	auto selectedItem = g_Data.getLocalPlayer()->getSelectedItem();
	if ((selectedItem == nullptr || selectedItem->count == 0 || selectedItem->item == nullptr || !selectedItem->getItem()->isBlock()))  // Block in hand?
		return;

	targetList18.clear();
	g_Data.forEachEntity(findEntity18);

	int place = 1;

	if (onClick) {
		if (GameData::isRightClickDown()) {
			place = 0;
		}
		else {
			place = 1;
		}
	}


	if (!onClick) {
		place = 0;
	}

	if (!targetList18.empty()) {
		//ground level
		vec3_t blockSideL1 = targetList18[0]->eyePos0;

		vec3_t blockSideR1 = targetList18[0]->eyePos0;

		vec3_t blockSideL2 = targetList18[0]->eyePos0;

		vec3_t blockSideL3 = targetList18[0]->eyePos0;

		vec3_t blockSideL4 = targetList18[0]->eyePos0;

		vec3_t blockSideR2 = targetList18[0]->eyePos0;

		vec3_t blockSideR3 = targetList18[0]->eyePos0;

		vec3_t blockSideR4 = targetList18[0]->eyePos0;

		//middle level
		vec3_t blockSideL1M = targetList18[0]->eyePos0;

		vec3_t blockSideR1M = targetList18[0]->eyePos0;

		vec3_t blockSideL2M = targetList18[0]->eyePos0;

		vec3_t blockSideL3M = targetList18[0]->eyePos0;

		vec3_t blockSideL4M = targetList18[0]->eyePos0;

		vec3_t blockSideR2M = targetList18[0]->eyePos0;

		vec3_t blockSideR3M = targetList18[0]->eyePos0;

		vec3_t blockSideR4M = targetList18[0]->eyePos0;

		//top level
		vec3_t blockSideL1T = targetList18[0]->eyePos0;

		vec3_t blockSideR1T = targetList18[0]->eyePos0;

		vec3_t blockSideL2T = targetList18[0]->eyePos0;

		vec3_t blockSideL3T = targetList18[0]->eyePos0;

		vec3_t blockSideL4T = targetList18[0]->eyePos0;

		vec3_t blockSideR2T = targetList18[0]->eyePos0;

		vec3_t blockSideR3T = targetList18[0]->eyePos0;

		vec3_t blockSideR4T = targetList18[0]->eyePos0;

		//above head level
		vec3_t blockAboveH1 = targetList18[0]->eyePos0;
		vec3_t blockAboveH2 = targetList18[0]->eyePos0;
		vec3_t blockAboveH3 = targetList18[0]->eyePos0;
		vec3_t blockAboveH4 = targetList18[0]->eyePos0;

		//blocks below player
		vec3_t blockBelowB1 = targetList18[0]->eyePos0;
		vec3_t blockBelowB2 = targetList18[0]->eyePos0;
		vec3_t blockBelowB3 = targetList18[0]->eyePos0;
		vec3_t blockBelowB4 = targetList18[0]->eyePos0;

		//ground level
		vec3_t blockSide1 = targetList18[0]->eyePos0;

		vec3_t blockSide2 = targetList18[0]->eyePos0;

		vec3_t blockSide3 = targetList18[0]->eyePos0;

		vec3_t blockSide4 = targetList18[0]->eyePos0;

		//middle level
		vec3_t blockSide5 = targetList18[0]->eyePos0;

		vec3_t blockSide6 = targetList18[0]->eyePos0;

		vec3_t blockSide7 = targetList18[0]->eyePos0;

		vec3_t blockSide8 = targetList18[0]->eyePos0;

		//top level
		vec3_t blockSide9 = targetList18[0]->eyePos0;

		vec3_t blockSide10 = targetList18[0]->eyePos0;

		vec3_t blockSide11 = targetList18[0]->eyePos0;

		vec3_t blockSide12 = targetList18[0]->eyePos0;

		vec3_t blockSide13 = targetList18[0]->eyePos0;

		vec3_t blockSide14 = targetList18[0]->eyePos0;

		vec3_t blockSide15 = targetList18[0]->eyePos0;

		vec3_t blockSide16 = targetList18[0]->eyePos0;

		vec3_t blockSide17 = targetList18[0]->eyePos0;

		vec3_t blockSide18 = targetList18[0]->eyePos0;

		vec3_t blockSide19 = targetList18[0]->eyePos0;

		vec3_t blockSide20 = targetList18[0]->eyePos0;

		vec3_t blockSide21 = targetList18[0]->eyePos0;

		vec3_t blockSide22 = targetList18[0]->eyePos0;

		vec3_t blockSide23 = targetList18[0]->eyePos0;

		vec3_t blockSide24 = targetList18[0]->eyePos0;

		vec3_t blockSide25 = targetList18[0]->eyePos0;

		vec3_t blockSide26 = targetList18[0]->eyePos0;

		vec3_t blockSide27 = targetList18[0]->eyePos0;

		vec3_t blockSide28 = targetList18[0]->eyePos0;

		vec3_t blockSide29 = targetList18[0]->eyePos0;

		vec3_t blockSide30 = targetList18[0]->eyePos0;

		vec3_t blockSide31 = targetList18[0]->eyePos0;

		vec3_t blockSide32 = targetList18[0]->eyePos0;

		//above players head
		vec3_t blockAbove = targetList18[0]->eyePos0;
		vec3_t blockAbove1 = targetList18[0]->eyePos0;
		vec3_t blockAbove2 = targetList18[0]->eyePos0;
		vec3_t blockAbove3 = targetList18[0]->eyePos0;
		vec3_t blockAbove4 = targetList18[0]->eyePos0;
		vec3_t blockAbove5 = targetList18[0]->eyePos0;

		//block below player
		vec3_t blockBelow = targetList18[0]->eyePos0;
		vec3_t blockBelow1 = targetList18[0]->eyePos0;
		vec3_t blockBelow2 = targetList18[0]->eyePos0;
		vec3_t blockBelow3 = targetList18[0]->eyePos0;
		vec3_t blockBelow4 = targetList18[0]->eyePos0;

		//ground level
		blockSideL1.x -= targetList18[0]->height + 0;
		blockSideL1.z -= targetList18[0]->height - 1;
		blockSideL1.y -= targetList18[0]->height - 1;

		blockSideR1.x -= targetList18[0]->height + 0;
		blockSideR1.z += targetList18[0]->height - 1;
		blockSideR1.y -= targetList18[0]->height - 1;

		blockSideL2.x += targetList18[0]->height + 0;
		blockSideL2.z -= targetList18[0]->height - 1;
		blockSideL2.y -= targetList18[0]->height - 1;

		blockSideR2.x += targetList18[0]->height + 0;
		blockSideR2.z += targetList18[0]->height - 1;
		blockSideR2.y -= targetList18[0]->height - 1;

		blockSideL3.x -= targetList18[0]->height - 1;
		blockSideL3.z -= targetList18[0]->height + 0;
		blockSideL3.y -= targetList18[0]->height - 1;

		blockSideR3.x -= targetList18[0]->height - 1;
		blockSideR3.z += targetList18[0]->height + 0;
		blockSideR3.y -= targetList18[0]->height - 1;

		blockSideL4.x += targetList18[0]->height - 1;
		blockSideL4.z -= targetList18[0]->height + 0;
		blockSideL4.y -= targetList18[0]->height - 1;

		blockSideR4.x += targetList18[0]->height - 1;
		blockSideR4.z += targetList18[0]->height + 0;
		blockSideR4.y -= targetList18[0]->height - 1;

		//middle level
		blockSideL1M.x -= targetList18[0]->height + 0;
		blockSideL1M.z -= targetList18[0]->height - 1;
		blockSideL1M.y += targetList18[0]->height - 2;

		blockSideR1M.x -= targetList18[0]->height + 0;
		blockSideR1M.z += targetList18[0]->height - 1;
		blockSideR1M.y += targetList18[0]->height - 2;

		blockSideL2M.x += targetList18[0]->height + 0;
		blockSideL2M.z -= targetList18[0]->height - 1;
		blockSideL2M.y += targetList18[0]->height - 2;

		blockSideR2M.x += targetList18[0]->height + 0;
		blockSideR2M.z += targetList18[0]->height - 1;
		blockSideR2M.y += targetList18[0]->height - 2;

		blockSideL3M.x -= targetList18[0]->height - 1;
		blockSideL3M.z -= targetList18[0]->height + 0;
		blockSideL3M.y += targetList18[0]->height - 2;

		blockSideR3M.x -= targetList18[0]->height - 1;
		blockSideR3M.z += targetList18[0]->height + 0;
		blockSideR3M.y += targetList18[0]->height - 2;

		blockSideL4M.x += targetList18[0]->height - 1;
		blockSideL4M.z -= targetList18[0]->height + 0;
		blockSideL4M.y += targetList18[0]->height - 2;

		blockSideR4M.x += targetList18[0]->height - 1;
		blockSideR4M.z += targetList18[0]->height + 0;
		blockSideR4M.y += targetList18[0]->height - 2;

		//top level
		blockSideL1T.x -= targetList18[0]->height + 0;
		blockSideL1T.z -= targetList18[0]->height - 1;
		blockSideL1T.y -= targetList18[0]->height - 3;

		blockSideR1T.x -= targetList18[0]->height + 0;
		blockSideR1T.z += targetList18[0]->height - 1;
		blockSideR1T.y -= targetList18[0]->height - 3;

		blockSideL2T.x += targetList18[0]->height + 0;
		blockSideL2T.z -= targetList18[0]->height - 1;
		blockSideL2T.y -= targetList18[0]->height - 3;

		blockSideR2T.x += targetList18[0]->height + 0;
		blockSideR2T.z += targetList18[0]->height - 1;
		blockSideR2T.y -= targetList18[0]->height - 3;

		blockSideL3T.x -= targetList18[0]->height - 1;
		blockSideL3T.z -= targetList18[0]->height + 0;
		blockSideL3T.y -= targetList18[0]->height - 3;

		blockSideR3T.x -= targetList18[0]->height - 1;
		blockSideR3T.z += targetList18[0]->height + 0;
		blockSideR3T.y -= targetList18[0]->height - 3;

		blockSideL4T.x += targetList18[0]->height - 1;
		blockSideL4T.z -= targetList18[0]->height + 0;
		blockSideL4T.y -= targetList18[0]->height - 3;

		blockSideR4T.x += targetList18[0]->height - 1;
		blockSideR4T.z += targetList18[0]->height + 0;
		blockSideR4T.y -= targetList18[0]->height - 3;

		//H1 x + z above head level
		blockAboveH1.y -= targetList18[0]->height - 3;
		blockAboveH1.x -= targetList18[0]->height - 1;
		blockAboveH1.z -= targetList18[0]->height - 1;

		blockAboveH2.y -= targetList18[0]->height - 3;
		blockAboveH2.x -= targetList18[0]->height - 1;
		blockAboveH2.z += targetList18[0]->height - 1;

		blockAboveH3.y -= targetList18[0]->height - 3;
		blockAboveH3.x += targetList18[0]->height - 1;
		blockAboveH3.z -= targetList18[0]->height - 1;

		blockAboveH4.y -= targetList18[0]->height - 3;
		blockAboveH4.x += targetList18[0]->height - 1;
		blockAboveH4.z += targetList18[0]->height - 1;

		//below Player B1 to B4
		blockBelowB1.y -= targetList18[0]->height + 0;
		blockBelowB1.x -= targetList18[0]->height - 1;
		blockBelowB1.z -= targetList18[0]->height - 1;

		blockBelowB2.y -= targetList18[0]->height + 0;
		blockBelowB2.x -= targetList18[0]->height - 1;
		blockBelowB2.z += targetList18[0]->height - 1;

		blockBelowB3.y -= targetList18[0]->height + 0;
		blockBelowB3.x += targetList18[0]->height - 1;
		blockBelowB3.z -= targetList18[0]->height - 1;

		blockBelowB4.y -= targetList18[0]->height + 0;
		blockBelowB4.x += targetList18[0]->height - 1;
		blockBelowB4.z += targetList18[0]->height - 1;

		//ground level
		blockSide1.x -= targetList18[0]->height + 0;
		blockSide1.y -= targetList18[0]->height - 1;

		blockSide2.x += targetList18[0]->height + 0;
		blockSide2.y -= targetList18[0]->height - 1;

		blockSide3.z -= targetList18[0]->height + 0;
		blockSide3.y -= targetList18[0]->height - 1;

		blockSide4.z += targetList18[0]->height + 0;
		blockSide4.y -= targetList18[0]->height - 1;

		//middle level
		blockSide5.x -= targetList18[0]->height + 0;
		blockSide6.x += targetList18[0]->height + 0;
		blockSide7.z -= targetList18[0]->height + 0;
		blockSide8.z += targetList18[0]->height + 0;

		//top level
		blockSide9.x -= targetList18[0]->height + 0;
		blockSide9.y -= targetList18[0]->height - 3;

		blockSide10.x += targetList18[0]->height + 0;
		blockSide10.y -= targetList18[0]->height - 3;

		blockSide11.z -= targetList18[0]->height + 0;
		blockSide11.y -= targetList18[0]->height - 3;

		blockSide12.z += targetList18[0]->height + 0;
		blockSide12.y -= targetList18[0]->height - 3;

		blockSide13.x += targetList18[0]->height + 0;
		blockSide13.y -= targetList18[0]->height - 4;

		blockSide14.z += targetList18[0]->height + 0;
		blockSide14.y -= targetList18[0]->height - 4;

		blockSide15.x -= targetList18[0]->height - 0;
		blockSide15.y -= targetList18[0]->height - 4;

		blockSide16.z -= targetList18[0]->height - 0;
		blockSide16.y -= targetList18[0]->height - 4;







		blockSide17.x += targetList18[0]->height + 0;
		blockSide17.y -= targetList18[0]->height - 5;

		blockSide18.z += targetList18[0]->height + 0;
		blockSide18.y -= targetList18[0]->height - 5;

		blockSide19.x -= targetList18[0]->height - 0;
		blockSide19.y -= targetList18[0]->height - 5;

		blockSide20.z -= targetList18[0]->height - 0;
		blockSide20.y -= targetList18[0]->height - 5;



		blockSide21.x += targetList18[0]->height + 0;
		blockSide21.y -= targetList18[0]->height - 6;

		blockSide22.z += targetList18[0]->height + 0;
		blockSide22.y -= targetList18[0]->height - 6;

		blockSide23.x -= targetList18[0]->height - 0;
		blockSide23.y -= targetList18[0]->height - 6;

		blockSide24.z -= targetList18[0]->height - 0;
		blockSide24.y -= targetList18[0]->height - 6;

		blockSide25.x += targetList18[0]->height + 0;
		blockSide25.y -= targetList18[0]->height - 7;

		blockSide26.z += targetList18[0]->height + 0;
		blockSide26.y -= targetList18[0]->height - 7;

		blockSide27.x -= targetList18[0]->height - 0;
		blockSide27.y -= targetList18[0]->height - 7;

		blockSide28.z -= targetList18[0]->height - 0;
		blockSide28.y -= targetList18[0]->height - 7;

		blockSide29.x += targetList18[0]->height + 0;
		blockSide29.y -= targetList18[0]->height - 8;

		blockSide30.z += targetList18[0]->height + 0;
		blockSide30.y -= targetList18[0]->height - 8;

		blockSide31.x -= targetList18[0]->height - 0;
		blockSide31.y -= targetList18[0]->height - 8;

		blockSide32.z -= targetList18[0]->height - 0;
		blockSide32.y -= targetList18[0]->height - 8;












		//above players head
		blockAbove.y -= targetList18[0]->height - 3;

		blockAbove1.y -= targetList18[0]->height - 3;
		blockAbove1.x -= targetList18[0]->height - 1;

		blockAbove2.y -= targetList18[0]->height - 3;
		blockAbove2.x += targetList18[0]->height - 1;

		blockAbove3.y -= targetList18[0]->height - 3;
		blockAbove3.z -= targetList18[0]->height - 1;

		blockAbove4.y -= targetList18[0]->height - 3;
		blockAbove4.z += targetList18[0]->height - 1;

		blockAbove5.y -= targetList18[0]->height - 3;
		blockAbove5.z += targetList18[0]->height - 0;

		//block below player
		blockBelow.y -= targetList18[0]->height + 0;

		blockBelow1.y -= targetList18[0]->height + 0;
		blockBelow1.x -= targetList18[0]->height - 1;

		blockBelow2.y -= targetList18[0]->height + 0;
		blockBelow2.x += targetList18[0]->height - 1;

		blockBelow3.y -= targetList18[0]->height + 0;
		blockBelow3.z -= targetList18[0]->height - 1;

		blockBelow4.y -= targetList18[0]->height + 0;
		blockBelow4.z += targetList18[0]->height - 1;

		if (place == 0) {
			// L1 to R4 are x + z sides ground level
			int slotab = 0;
			C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
			C_Inventory* inv = supplies->inventory;
			slotab = supplies->selectedHotbarSlot;
			for (int n = 0; n < 9; n++) {
				C_ItemStack* stack = inv->getItemStack(n);
				if (stack->item != nullptr) {
					if (stack->getItem()->itemId == 49) {
						supplies->selectedHotbarSlot = n;
						break;
					}
				}
			}
			if (!tryTrapAnvil(blockAboveH1)) {
				blockAboveH1.x -= 0;
				blockAboveH1.z -= 0;
			}

			if (!tryTrapAnvil(blockAboveH2)) {
				blockAboveH2.x -= 0;
				blockAboveH2.z -= 0;
			}

			if (!tryTrapAnvil(blockAboveH3)) {
				blockAboveH3.x -= 0;
				blockAboveH3.z -= 0;
			}

			if (!tryTrapAnvil(blockAboveH4)) {
				blockAboveH4.x -= 0;
				blockAboveH4.z -= 0;
			}

			//B1 to B4 below the player
			if (!tryTrapAnvil(blockBelowB1)) {
				blockBelowB1.x -= 0;
				blockBelowB1.z -= 0;
			}

			if (!tryTrapAnvil(blockBelowB2)) {
				blockBelowB2.x -= 0;
				blockBelowB2.z -= 0;
			}

			if (!tryTrapAnvil(blockBelowB3)) {
				blockBelowB3.x -= 0;
				blockBelowB3.z -= 0;
			}

			if (!tryTrapAnvil(blockBelowB4)) {
				blockBelowB4.x -= 0;
				blockBelowB4.z -= 0;
			}

			//blockSide 1 to 4 are placing at ground level around the player
			
			if (obsiheight <= 3) {
				int slotab = 0;
				C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
				C_Inventory* inv = supplies->inventory;
				slotab = supplies->selectedHotbarSlot;
				for (int n = 0; n < 9; n++) {
					C_ItemStack* stack = inv->getItemStack(n);
					if (stack->item != nullptr) {
						if (stack->getItem()->itemId == 49) {
							supplies->selectedHotbarSlot = n;
							break;
						}
					}
				}
				if (!tryTrapAnvil(blockSide1)) {
					blockSide1.y -= 0;
					blockSide1.x -= 0;
				}

				if (!tryTrapAnvil(blockSide2)) {
					blockSide2.y += 0;
					blockSide2.x += 0;
				}

				if (!tryTrapAnvil(blockSide3)) {
					blockSide3.y -= 0;
					blockSide3.z -= 0;
				}

				if (!tryTrapAnvil(blockSide4)) {
					blockSide4.y += 0;
					blockSide4.z += 0;
				}

				//blockSide 5 to 8 are placing 1 up around the player
				if (!tryTrapAnvil(blockSide5)) {
					blockSide5.x -= 0;
				}

				if (!tryTrapAnvil(blockSide6)) {
					blockSide6.x += 0;
				}

				if (!tryTrapAnvil(blockSide7)) {
					blockSide7.z -= 0;
				}

				if (!tryTrapAnvil(blockSide8)) {
					blockSide8.z += 0;
				}

				//blockSide 9 to 12 at players head and around
				if (!tryTrapAnvil(blockSide9)) {
					blockSide9.y -= 0;
					blockSide9.x -= 0;
				}

				if (!tryTrapAnvil(blockSide10)) {
					blockSide10.y -= 0;
					blockSide10.x += 0;
				}

				if (!tryTrapAnvil(blockSide11)) {
					blockSide11.y -= 0;
					blockSide11.z -= 0;
				}

				if (!tryTrapAnvil(blockSide12)) {
					blockSide12.y -= 0;
					blockSide12.z += 0;
				}
				supplies->selectedHotbarSlot = slotab;

			}
			if (obsiheight == 4) {
				int slotab = 0;
				C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
				C_Inventory* inv = supplies->inventory;
				slotab = supplies->selectedHotbarSlot;
				for (int n = 0; n < 9; n++) {
					C_ItemStack* stack = inv->getItemStack(n);
					if (stack->item != nullptr) {
						if (stack->getItem()->itemId == 49) {
							supplies->selectedHotbarSlot = n;
							break;
						}
					}
				}
				if (!tryTrapAnvil(blockSide1)) {
					blockSide1.y -= 0;
					blockSide1.x -= 0;
				}

				if (!tryTrapAnvil(blockSide2)) {
					blockSide2.y += 0;
					blockSide2.x += 0;
				}

				if (!tryTrapAnvil(blockSide3)) {
					blockSide3.y -= 0;
					blockSide3.z -= 0;
				}

				if (!tryTrapAnvil(blockSide4)) {
					blockSide4.y += 0;
					blockSide4.z += 0;
				}

				//blockSide 5 to 8 are placing 1 up around the player
				if (!tryTrapAnvil(blockSide5)) {
					blockSide5.x -= 0;
				}

				if (!tryTrapAnvil(blockSide6)) {
					blockSide6.x += 0;
				}

				if (!tryTrapAnvil(blockSide7)) {
					blockSide7.z -= 0;
				}

				if (!tryTrapAnvil(blockSide8)) {
					blockSide8.z += 0;
				}

				//blockSide 9 to 12 at players head and around
				if (!tryTrapAnvil(blockSide9)) {
					blockSide9.y -= 0;
					blockSide9.x -= 0;
				}

				if (!tryTrapAnvil(blockSide10)) {
					blockSide10.y -= 0;
					blockSide10.x += 0;
				}

				if (!tryTrapAnvil(blockSide11)) {
					blockSide11.y -= 0;
					blockSide11.z -= 0;
				}

				if (!tryTrapAnvil(blockSide12)) {
					blockSide12.y -= 0;
					blockSide12.z += 0;
				}
				if (!tryTrapAnvil(blockSide13)) {
					blockSide13.y -= 0;
					blockSide13.z += 0;
				}
				if (!tryTrapAnvil(blockSide14)) {
					blockSide14.y -= 0;
					blockSide14.z += 0;
				}
				if (!tryTrapAnvil(blockSide15)) {
					blockSide15.y -= 0;
					blockSide15.z += 0;
				}
				if (!tryTrapAnvil(blockSide16)) {
					blockSide16.y -= 0;
					blockSide16.z += 0;
				}
				supplies->selectedHotbarSlot = slotab;

			}
			if (obsiheight == 5) {
				int slotab = 0;
				C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
				C_Inventory* inv = supplies->inventory;
				slotab = supplies->selectedHotbarSlot;
				for (int n = 0; n < 9; n++) {
					C_ItemStack* stack = inv->getItemStack(n);
					if (stack->item != nullptr) {
						if (stack->getItem()->itemId == 49) {
							supplies->selectedHotbarSlot = n;
							break;
						}
					}
				}
				if (!tryTrapAnvil(blockSide1)) {
					blockSide1.y -= 0;
					blockSide1.x -= 0;
				}

				if (!tryTrapAnvil(blockSide2)) {
					blockSide2.y += 0;
					blockSide2.x += 0;
				}

				if (!tryTrapAnvil(blockSide3)) {
					blockSide3.y -= 0;
					blockSide3.z -= 0;
				}

				if (!tryTrapAnvil(blockSide4)) {
					blockSide4.y += 0;
					blockSide4.z += 0;
				}

				//blockSide 5 to 8 are placing 1 up around the player
				if (!tryTrapAnvil(blockSide5)) {
					blockSide5.x -= 0;
				}

				if (!tryTrapAnvil(blockSide6)) {
					blockSide6.x += 0;
				}

				if (!tryTrapAnvil(blockSide7)) {
					blockSide7.z -= 0;
				}

				if (!tryTrapAnvil(blockSide8)) {
					blockSide8.z += 0;
				}

				//blockSide 9 to 12 at players head and around
				if (!tryTrapAnvil(blockSide9)) {
					blockSide9.y -= 0;
					blockSide9.x -= 0;
				}

				if (!tryTrapAnvil(blockSide10)) {
					blockSide10.y -= 0;
					blockSide10.x += 0;
				}

				if (!tryTrapAnvil(blockSide11)) {
					blockSide11.y -= 0;
					blockSide11.z -= 0;
				}

				if (!tryTrapAnvil(blockSide12)) {
					blockSide12.y -= 0;
					blockSide12.z += 0;
				}
				if (!tryTrapAnvil(blockSide13)) {
					blockSide13.y -= 0;
					blockSide13.z += 0;
				}
				if (!tryTrapAnvil(blockSide14)) {
					blockSide14.y -= 0;
					blockSide14.z += 0;
				}
				if (!tryTrapAnvil(blockSide15)) {
					blockSide15.y -= 0;
					blockSide15.z += 0;
				}
				if (!tryTrapAnvil(blockSide16)) {
					blockSide16.y -= 0;
					blockSide16.z += 0;
				}
				if (!tryTrapAnvil(blockSide17)) {
					blockSide17.y -= 0;
					blockSide17.z += 0;
				}
				if (!tryTrapAnvil(blockSide18)) {
					blockSide18.y -= 0;
					blockSide18.z += 0;
				}
				if (!tryTrapAnvil(blockSide19)) {
					blockSide19.y -= 0;
					blockSide19.z += 0;
				}
				if (!tryTrapAnvil(blockSide20)) {
					blockSide20.y -= 0;
					blockSide20.z += 0;
				}

				supplies->selectedHotbarSlot = slotab;

			}
			if (obsiheight == 6) {
				int slotab = 0;
				C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
				C_Inventory* inv = supplies->inventory;
				slotab = supplies->selectedHotbarSlot;
				for (int n = 0; n < 9; n++) {
					C_ItemStack* stack = inv->getItemStack(n);
					if (stack->item != nullptr) {
						if (stack->getItem()->itemId == 49) {
							supplies->selectedHotbarSlot = n;
							break;
						}
					}
				}
				if (!tryTrapAnvil(blockSide1)) {
					blockSide1.y -= 0;
					blockSide1.x -= 0;
				}

				if (!tryTrapAnvil(blockSide2)) {
					blockSide2.y += 0;
					blockSide2.x += 0;
				}

				if (!tryTrapAnvil(blockSide3)) {
					blockSide3.y -= 0;
					blockSide3.z -= 0;
				}

				if (!tryTrapAnvil(blockSide4)) {
					blockSide4.y += 0;
					blockSide4.z += 0;
				}

				//blockSide 5 to 8 are placing 1 up around the player
				if (!tryTrapAnvil(blockSide5)) {
					blockSide5.x -= 0;
				}

				if (!tryTrapAnvil(blockSide6)) {
					blockSide6.x += 0;
				}

				if (!tryTrapAnvil(blockSide7)) {
					blockSide7.z -= 0;
				}

				if (!tryTrapAnvil(blockSide8)) {
					blockSide8.z += 0;
				}

				//blockSide 9 to 12 at players head and around
				if (!tryTrapAnvil(blockSide9)) {
					blockSide9.y -= 0;
					blockSide9.x -= 0;
				}

				if (!tryTrapAnvil(blockSide10)) {
					blockSide10.y -= 0;
					blockSide10.x += 0;
				}

				if (!tryTrapAnvil(blockSide11)) {
					blockSide11.y -= 0;
					blockSide11.z -= 0;
				}

				if (!tryTrapAnvil(blockSide12)) {
					blockSide12.y -= 0;
					blockSide12.z += 0;
				}
				if (!tryTrapAnvil(blockSide13)) {
					blockSide13.y -= 0;
					blockSide13.z += 0;
				}
				if (!tryTrapAnvil(blockSide14)) {
					blockSide14.y -= 0;
					blockSide14.z += 0;
				}
				if (!tryTrapAnvil(blockSide15)) {
					blockSide15.y -= 0;
					blockSide15.z += 0;
				}
				if (!tryTrapAnvil(blockSide16)) {
					blockSide16.y -= 0;
					blockSide16.z += 0;
				}
				if (!tryTrapAnvil(blockSide17)) {
					blockSide17.y -= 0;
					blockSide17.z += 0;
				}
				if (!tryTrapAnvil(blockSide18)) {
					blockSide18.y -= 0;
					blockSide18.z += 0;
				}
				if (!tryTrapAnvil(blockSide19)) {
					blockSide19.y -= 0;
					blockSide19.z += 0;
				}
				if (!tryTrapAnvil(blockSide20)) {
					blockSide20.y -= 0;
					blockSide20.z += 0;
				}
				if (!tryTrapAnvil(blockSide21)) {
					blockSide21.y -= 0;
					blockSide21.z += 0;
				}
				if (!tryTrapAnvil(blockSide22)) {
					blockSide22.y -= 0;
					blockSide22.z += 0;
				}
				if (!tryTrapAnvil(blockSide23)) {
					blockSide23.y -= 0;
					blockSide23.z += 0;
				}
				if (!tryTrapAnvil(blockSide24)) {
					blockSide24.y -= 0;
					blockSide24.z += 0;
				}

				supplies->selectedHotbarSlot = slotab;

			}
			if (obsiheight == 7) {
				int slotab = 0;
				C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
				C_Inventory* inv = supplies->inventory;
				slotab = supplies->selectedHotbarSlot;
				for (int n = 0; n < 9; n++) {
					C_ItemStack* stack = inv->getItemStack(n);
					if (stack->item != nullptr) {
						if (stack->getItem()->itemId == 49) {
							supplies->selectedHotbarSlot = n;
							break;
						}
					}
				}
				if (!tryTrapAnvil(blockSide1)) {
					blockSide1.y -= 0;
					blockSide1.x -= 0;
				}

				if (!tryTrapAnvil(blockSide2)) {
					blockSide2.y += 0;
					blockSide2.x += 0;
				}

				if (!tryTrapAnvil(blockSide3)) {
					blockSide3.y -= 0;
					blockSide3.z -= 0;
				}

				if (!tryTrapAnvil(blockSide4)) {
					blockSide4.y += 0;
					blockSide4.z += 0;
				}

				//blockSide 5 to 8 are placing 1 up around the player
				if (!tryTrapAnvil(blockSide5)) {
					blockSide5.x -= 0;
				}

				if (!tryTrapAnvil(blockSide6)) {
					blockSide6.x += 0;
				}

				if (!tryTrapAnvil(blockSide7)) {
					blockSide7.z -= 0;
				}

				if (!tryTrapAnvil(blockSide8)) {
					blockSide8.z += 0;
				}

				//blockSide 9 to 12 at players head and around
				if (!tryTrapAnvil(blockSide9)) {
					blockSide9.y -= 0;
					blockSide9.x -= 0;
				}

				if (!tryTrapAnvil(blockSide10)) {
					blockSide10.y -= 0;
					blockSide10.x += 0;
				}

				if (!tryTrapAnvil(blockSide11)) {
					blockSide11.y -= 0;
					blockSide11.z -= 0;
				}

				if (!tryTrapAnvil(blockSide12)) {
					blockSide12.y -= 0;
					blockSide12.z += 0;
				}
				if (!tryTrapAnvil(blockSide13)) {
					blockSide13.y -= 0;
					blockSide13.z += 0;
				}
				if (!tryTrapAnvil(blockSide14)) {
					blockSide14.y -= 0;
					blockSide14.z += 0;
				}
				if (!tryTrapAnvil(blockSide15)) {
					blockSide15.y -= 0;
					blockSide15.z += 0;
				}
				if (!tryTrapAnvil(blockSide16)) {
					blockSide16.y -= 0;
					blockSide16.z += 0;
				}
				if (!tryTrapAnvil(blockSide17)) {
					blockSide17.y -= 0;
					blockSide17.z += 0;
				}
				if (!tryTrapAnvil(blockSide18)) {
					blockSide18.y -= 0;
					blockSide18.z += 0;
				}
				if (!tryTrapAnvil(blockSide19)) {
					blockSide19.y -= 0;
					blockSide19.z += 0;
				}
				if (!tryTrapAnvil(blockSide20)) {
					blockSide20.y -= 0;
					blockSide20.z += 0;
				}
				if (!tryTrapAnvil(blockSide21)) {
					blockSide21.y -= 0;
					blockSide21.z += 0;
				}
				if (!tryTrapAnvil(blockSide22)) {
					blockSide22.y -= 0;
					blockSide22.z += 0;
				}
				if (!tryTrapAnvil(blockSide23)) {
					blockSide23.y -= 0;
					blockSide23.z += 0;
				}
				if (!tryTrapAnvil(blockSide24)) {
					blockSide24.y -= 0;
					blockSide24.z += 0;
				}
				if (!tryTrapAnvil(blockSide25)) {
					blockSide25.y -= 0;
					blockSide25.z += 0;
				}
				if (!tryTrapAnvil(blockSide26)) {
					blockSide26.y -= 0;
					blockSide26.z += 0;
				}
				if (!tryTrapAnvil(blockSide27)) {
					blockSide27.y -= 0;
					blockSide27.z += 0;
				}
				if (!tryTrapAnvil(blockSide28)) {
					blockSide28.y -= 0;
					blockSide28.z += 0;
				}

				supplies->selectedHotbarSlot = slotab;

			}
			if (obsiheight == 8) {
				int slotab = 0;
				C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
				C_Inventory* inv = supplies->inventory;
				slotab = supplies->selectedHotbarSlot;
				for (int n = 0; n < 9; n++) {
					C_ItemStack* stack = inv->getItemStack(n);
					if (stack->item != nullptr) {
						if (stack->getItem()->itemId == 49) {
							supplies->selectedHotbarSlot = n;
							break;
						}
					}
				}
				if (!tryTrapAnvil(blockSide1)) {
					blockSide1.y -= 0;
					blockSide1.x -= 0;
				}

				if (!tryTrapAnvil(blockSide2)) {
					blockSide2.y += 0;
					blockSide2.x += 0;
				}

				if (!tryTrapAnvil(blockSide3)) {
					blockSide3.y -= 0;
					blockSide3.z -= 0;
				}

				if (!tryTrapAnvil(blockSide4)) {
					blockSide4.y += 0;
					blockSide4.z += 0;
				}

				//blockSide 5 to 8 are placing 1 up around the player
				if (!tryTrapAnvil(blockSide5)) {
					blockSide5.x -= 0;
				}

				if (!tryTrapAnvil(blockSide6)) {
					blockSide6.x += 0;
				}

				if (!tryTrapAnvil(blockSide7)) {
					blockSide7.z -= 0;
				}

				if (!tryTrapAnvil(blockSide8)) {
					blockSide8.z += 0;
				}

				//blockSide 9 to 12 at players head and around
				if (!tryTrapAnvil(blockSide9)) {
					blockSide9.y -= 0;
					blockSide9.x -= 0;
				}

				if (!tryTrapAnvil(blockSide10)) {
					blockSide10.y -= 0;
					blockSide10.x += 0;
				}

				if (!tryTrapAnvil(blockSide11)) {
					blockSide11.y -= 0;
					blockSide11.z -= 0;
				}

				if (!tryTrapAnvil(blockSide12)) {
					blockSide12.y -= 0;
					blockSide12.z += 0;
				}
				if (!tryTrapAnvil(blockSide13)) {
					blockSide13.y -= 0;
					blockSide13.z += 0;
				}
				if (!tryTrapAnvil(blockSide14)) {
					blockSide14.y -= 0;
					blockSide14.z += 0;
				}
				if (!tryTrapAnvil(blockSide15)) {
					blockSide15.y -= 0;
					blockSide15.z += 0;
				}
				if (!tryTrapAnvil(blockSide16)) {
					blockSide16.y -= 0;
					blockSide16.z += 0;
				}
				if (!tryTrapAnvil(blockSide17)) {
					blockSide17.y -= 0;
					blockSide17.z += 0;
				}
				if (!tryTrapAnvil(blockSide18)) {
					blockSide18.y -= 0;
					blockSide18.z += 0;
				}
				if (!tryTrapAnvil(blockSide19)) {
					blockSide19.y -= 0;
					blockSide19.z += 0;
				}
				if (!tryTrapAnvil(blockSide20)) {
					blockSide20.y -= 0;
					blockSide20.z += 0;
				}
				if (!tryTrapAnvil(blockSide21)) {
					blockSide21.y -= 0;
					blockSide21.z += 0;
				}
				if (!tryTrapAnvil(blockSide22)) {
					blockSide22.y -= 0;
					blockSide22.z += 0;
				}
				if (!tryTrapAnvil(blockSide23)) {
					blockSide23.y -= 0;
					blockSide23.z += 0;
				}
				if (!tryTrapAnvil(blockSide24)) {
					blockSide24.y -= 0;
					blockSide24.z += 0;
				}
				if (!tryTrapAnvil(blockSide25)) {
					blockSide25.y -= 0;
					blockSide25.z += 0;
				}
				if (!tryTrapAnvil(blockSide26)) {
					blockSide26.y -= 0;
					blockSide26.z += 0;
				}
				if (!tryTrapAnvil(blockSide27)) {
					blockSide27.y -= 0;
					blockSide27.z += 0;
				}
				if (!tryTrapAnvil(blockSide28)) {
					blockSide28.y -= 0;
					blockSide28.z += 0;
				}
				if (!tryTrapAnvil(blockSide29)) {
					blockSide29.y -= 0;
					blockSide29.z += 0;
				}
				if (!tryTrapAnvil(blockSide30)) {
					blockSide30.y -= 0;
					blockSide30.z += 0;
				}
				if (!tryTrapAnvil(blockSide31)) {
					blockSide31.y -= 0;
					blockSide31.z += 0;
				}
				if (!tryTrapAnvil(blockSide32)) {
					blockSide32.y -= 0;
					blockSide32.z += 0;
				}

				supplies->selectedHotbarSlot = slotab;

			}



			//placing block above players head (3blocks up from the ground)





			//below the player
			if (!tryTrapAnvil(blockBelow)) {
				blockBelow.x -= 0;
				blockBelow.z -= 0;
			}

			if (!tryTrapAnvil(blockBelow1)) {
				blockBelow1.x -= 0;
				blockBelow1.z -= 0;
			}

			if (!tryTrapAnvil(blockBelow2)) {
				blockBelow2.x -= 0;
				blockBelow2.z -= 0;
			}

			if (!tryTrapAnvil(blockBelow3)) {
				blockBelow3.x -= 0;
				blockBelow3.z -= 0;
			}
			supplies->selectedHotbarSlot = slotab;

			if (!tryTrapAnvil(blockBelow4)) {
				blockBelow4.x -= 0;
				blockBelow4.z -= 0;
			}
			slotab = supplies->selectedHotbarSlot;
			for (int n = 0; n < 9; n++) {
				C_ItemStack* stack = inv->getItemStack(n);
				if (stack->item != nullptr) {
					if (stack->getItem()->itemId == 145) { // itemid == 146
						supplies->selectedHotbarSlot = n;
						break;
					}
				}
			}
			if (!tryTrapAnvil(blockAbove)) {
				blockAbove.y -= 0;
			}

			if (!tryTrapAnvil(blockAbove1)) {
				blockAbove1.y -= 0;
			}

			if (!tryTrapAnvil(blockAbove2)) {
				blockAbove2.y -= 0;
			}

			if (!tryTrapAnvil(blockAbove3)) {
				blockAbove3.y -= 0;
			}

			if (!tryTrapAnvil(blockAbove4)) {
				blockAbove4.y -= 0;
			}
			if (!tryTrapAnvil(blockAbove5)) {
				blockAbove5.y -= 0;
			}
			supplies->selectedHotbarSlot = slotab;
		}
	}
}
