#pragma once
#include "../Module.h"
#include "../../../../Utils/TargetUtil.h"
#include "../../ModuleManager.h"
class AutoTrapPlus : public IModule {
private:

	bool tryAutoTrapPlus(vec3_t AutoTrapPlus);

public:
	AutoTrapPlus();
	~AutoTrapPlus();
	int range = 8;
	bool onClick = false;
	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onTick(C_GameMode* gm) override;
};
