#include "BedAura.h"
#include "../pch.h"
int range = 4;
using namespace std;
BedAura::BedAura() : IModule(0, Category::COMBAT, "Automatically BedAura at the nearest entity") {
	registerIntSetting("Range", &range, range, 3, 6);
}

static std::vector<C_Entity*> BedTarget;

void findBedTarget(C_Entity* BedEntity, bool isRegularEntity) {
	static auto BedAuraMod = moduleMgr->getModule<BedAura>();

	if (BedEntity == nullptr)
		return;

	if (BedEntity == g_Data.getLocalPlayer())  // Skip Local player
		return;

	if (!g_Data.getLocalPlayer()->canAttack(BedEntity, false))
		return;

	if (!g_Data.getLocalPlayer()->isAlive())
		return;

	if (!BedEntity->isAlive())
		return;


	if (!TargetUtil::isValidTarget(BedEntity))
		return;

	float dist = (*BedEntity->getPos()).dist(*g_Data.getLocalPlayer()->getPos());
	if (dist < range) {
		BedTarget.push_back(BedEntity);

		float dist = (*BedEntity->getPos()).dist(*g_Data.getLocalPlayer()->getPos());

		if (dist < range) {
			BedTarget.push_back(BedEntity);
		}
	}
}
const char* BedAura::getModuleName() {
	return ("BedAura");
}

bool tryBedAura(vec3_t BedAura) {
	BedAura = BedAura.floor();

	C_Block* block = g_Data.getLocalPlayer()->region->getBlock(vec3_ti(BedAura));
	C_BlockLegacy* blockLegacy = (block->blockLegacy);
	if (blockLegacy->material->isReplaceable) {
		vec3_ti blok(BedAura);

		// Find neighbour
		static std::vector<vec3_ti*> checklist;
		if (checklist.empty()) {
			checklist.push_back(new vec3_ti(0, -1, 0));
			checklist.push_back(new vec3_ti(0, 1, 0));

			checklist.push_back(new vec3_ti(0, 0, -1));
			checklist.push_back(new vec3_ti(0, 0, 1));

			checklist.push_back(new vec3_ti(-1, 0, 0));
			checklist.push_back(new vec3_ti(1, 0, 0));
		}

		bool foundCandidate = false;
		int i = 0;
		for (auto current : checklist) {
			vec3_ti calc = blok.sub(*current);
			bool Y = ((g_Data.getLocalPlayer()->region->getBlock(calc)->blockLegacy))->material->isReplaceable;
			if (!((g_Data.getLocalPlayer()->region->getBlock(calc)->blockLegacy))->material->isReplaceable) {
				// Found a solid block to click
				foundCandidate = true;
				blok = calc;
				break;
			}
			i++;
		}
		if (foundCandidate) {
			g_Data.getCGameMode()->buildBlock(&blok, i);

			return true;
		}
	}
}

void BedAura::onTick(C_GameMode* gm) {
	C_GameSettingsInput* input = g_Data.getClientInstance()->getGameSettingsInput();
	if (g_Data.getLocalPlayer() == nullptr && !g_Data.canUseMoveKeys()) {
		return;
	}
	BedTarget.clear();
	g_Data.forEachEntity(findBedTarget);

	if (!BedTarget.empty()) {
		vec3_t BedPos = BedTarget[0]->eyePos0;
		BedPos.x -=     BedTarget[0]->height - 2;
		BedPos.z -=     BedTarget[0]->height - 0;
		BedPos.y -=     BedTarget[0]->height + 1;

		int slotab = 0;
		C_PlayerInventoryProxy* supplies = g_Data.getLocalPlayer()->getSupplies();
		C_Inventory* inv = supplies->inventory;
		slotab = supplies->selectedHotbarSlot;
		for (int n = 0; n < 9; n++) {
			C_ItemStack* stack = inv->getItemStack(n);
			if (stack->item != nullptr) {
				if (stack->getItem()->itemId == 26) {
					supplies->selectedHotbarSlot = n;
					break;
				}
			}
		}
		if (!tryBedAura(BedPos)) {
			BedPos.x -= 0;
			BedPos.z -= 0;
			BedPos.y -= 0;
		}
		if (!tryBedAura(BedPos)) {
			BedPos.x -= 0;
			BedPos.z -= 0;
			BedPos.y -= 0;
		}
		supplies->selectedHotbarSlot = slotab;
	}
}