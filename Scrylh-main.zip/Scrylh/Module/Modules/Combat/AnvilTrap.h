#pragma once
#include "../Module.h"
#include "../../../../Utils/TargetUtil.h"
#include "../../ModuleManager.h"
class AnvilTrap : public IModule {
private:

	bool tryAnvilTrap123(vec3_t AnvilTrap);

public:
	AnvilTrap();
	~AnvilTrap();
	int range = 7;
	bool onClick = false;
	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onTick(C_GameMode* gm) override;
};
