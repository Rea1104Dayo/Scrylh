#pragma once
#include "../Module.h"
class SelfAnvil : public IModule {
private:
	bool trySelfAnvil(vec3_t SelfAnvil);
	int placed = 0;
public:
	SelfAnvil();
	~SelfAnvil();
	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onTick(C_GameMode* gm) override;
	virtual void onDisable() override;
};
